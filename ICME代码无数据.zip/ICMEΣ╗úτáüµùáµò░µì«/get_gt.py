import pickle

pkl_file1 = open('/public/home/zhangy/v2_Non-Autoregressive-Video-Captioning-master/VC_data/MSRVTT/info_corpus.pkl', 'rb')

data1 = pickle.load(pkl_file1)

